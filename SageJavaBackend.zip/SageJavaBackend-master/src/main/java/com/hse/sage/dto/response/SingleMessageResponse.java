package com.hse.sage.dto.response;

import lombok.Data;

@Data
public class SingleMessageResponse {
    private ChatMessageResponse message;
}
