package com.hse.sage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheSageApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheSageApplication.class, args);
	}
}
