package com.hse.sage.constants;

public enum RequestType {
    TIMER,
    ERROR_EXPLAIN,
    CHAT_ANALYZE
}