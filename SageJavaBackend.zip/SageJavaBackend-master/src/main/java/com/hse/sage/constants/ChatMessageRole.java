package com.hse.sage.constants;

public enum ChatMessageRole {
    STUDENT,
    SAGE
}
